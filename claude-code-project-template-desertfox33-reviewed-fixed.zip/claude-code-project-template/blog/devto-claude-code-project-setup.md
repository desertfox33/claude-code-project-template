---
title: "How to Set Up Claude Code for a Project with Skills, Agents, Hooks, and Secure GitHub Publishing"
published: false
description: "A practical guide to building a Claude Code project template with reusable skills, agents, commands, hooks, memory, and public GitHub security controls."
tags: ai, claude, github, cybersecurity
canonical_url: https://github.com/desertfox33/claude-code-project-template
---

# How to Set Up Claude Code for a Project with Skills, Agents, Hooks, and Secure GitHub Publishing

Claude Code becomes far more useful when the project gives it structure. A clean project setup tells Claude what the repository is, how to work safely, which standards to follow, and when to use specialized skills.

This article walks through a full Claude Code project template that you can publish under your own GitHub account:

```text
https://github.com/desertfox33/claude-code-project-template
```

The goal is not just to make Claude write code. The goal is to make Claude work inside a controlled project environment with reusable instructions, repeatable workflows, security guardrails, and clear documentation.

## What this project includes

The repository uses this structure:

```text
claude-code-project-template/
├── CLAUDE.md
├── CLAUDE.local.md.example
├── .claude/
│   ├── settings.json
│   ├── settings.local.json.example
│   ├── skills/
│   ├── agents/
│   ├── commands/
│   ├── hooks/
│   ├── rules/
│   ├── memory/
│   └── workflows/
├── .github/
│   ├── CODEOWNERS
│   ├── dependabot.yml
│   ├── pull_request_template.md
│   └── workflows/
├── blog/
├── docs/
├── scripts/
├── README.md
├── SECURITY.md
├── CONTRIBUTING.md
└── .gitignore
```

Each part has a different job. The mistake many teams make is putting every instruction into one large prompt. That works for a small experiment, but it becomes hard to maintain. A better pattern is to split persistent context, reusable procedures, specialized agents, commands, and guardrails into the right files.

## 1. Start with `CLAUDE.md`

`CLAUDE.md` is the project instruction file. Use it for information Claude should know at the start of every session.

In this repository, `CLAUDE.md` tells Claude:

- The repository belongs to `desertfox33`
- The official repository link is `https://github.com/desertfox33/claude-code-project-template`
- The project is public and security-conscious
- Real secrets must never be created or committed
- Destructive Git and shell commands require caution
- Skills should be used when the request matches the task

Use `CLAUDE.md` for stable guidance such as coding standards, project layout, safe command rules, and documentation ownership.

Do not put long procedures into `CLAUDE.md`. Long repeatable procedures should become skills.

## 2. Use local files for private notes

The project includes:

```text
CLAUDE.local.md.example
.claude/settings.local.json.example
```

These are examples only. If you need local machine-specific preferences, copy them to:

```text
CLAUDE.local.md
.claude/settings.local.json
```

Those real local files are ignored by Git.

This protects private data such as local paths, private commands, personal tokens, and environment-specific notes.

## 3. Configure shared settings in `.claude/settings.json`

The shared settings file includes conservative permissions and hooks.

The template denies access to obvious sensitive files, including:

```text
.env
.env.*
secrets/**
credentials/**
*.pem
*.p12
*.pfx
```

It also asks for confirmation before risky commands such as Git pushes, pulls, resets, and command downloads.

This does not replace human review. It reduces accidental mistakes.

## 4. Add skills for repeatable work

Skills live here:

```text
.claude/skills/<skill-name>/SKILL.md
```

Each skill contains a description and a procedure. Claude can use a skill automatically when relevant, or you can invoke it directly with a slash command.

This project includes these skills:

| Skill | Use it when |
|---|---|
| `/code-review` | Reviewing code correctness, maintainability, and production risk |
| `/security-review` | Checking public repo safety, secrets, scripts, hooks, and automation |
| `/testing-patterns` | Designing practical tests for a change |
| `/pr-description` | Creating a GitHub pull request summary |
| `/documentation-writer` | Writing README, Dev.to, and setup documentation |
| `/threat-modeling` | Mapping assets, threats, controls, and residual risk |
| `/devsecops-cicd-review` | Reviewing GitHub Actions and CI/CD risk |
| `/cloud-iam-review` | Reviewing IAM examples and least privilege |
| `/api-security-review` | Reviewing API authentication, authorization, validation, and logging |
| `/incident-response-runbook` | Creating incident response steps |
| `/architecture-review` | Reviewing architecture and operational trade-offs |
| `/terraform-iac-review` | Reviewing IaC, Terraform, and cloud configuration |
| `/dependency-review` | Reviewing dependencies and supply-chain risk |
| `/docker-kubernetes-review` | Reviewing containers, Dockerfiles, and Kubernetes manifests |
| `/performance-review` | Reviewing performance-sensitive changes |
| `/refactoring-plan` | Planning safe refactoring work |

## 5. Which skills should you use?

Use `/documentation-writer` when updating the blog, README, setup guide, or Dev.to post.

Use `/security-review` before making the repository public, before changing hooks, before changing `.github/`, or before adding scripts.

Use `/devsecops-cicd-review` before editing GitHub Actions. Public repositories are often attacked through unsafe automation, excessive workflow permissions, or untrusted pull request execution.

Use `/testing-patterns` after any code or script change. Even documentation repositories have scripts and workflows that should be validated.

Use `/dependency-review` when adding a package manager file, dependency lock file, GitHub Action, or external tool.

Use `/threat-modeling` when you want to understand what could go wrong. For this repository, the main assets are repository integrity, GitHub account access, public trust, and any secrets accidentally placed in the repo.

Use `/pr-description` before opening a pull request so every change has a clear review trail.

## 6. Add subagents for focused review

Subagents live here:

```text
.claude/agents/
```

This project includes:

```text
security-reviewer.md
docs-editor.md
test-writer.md
devsecops-reviewer.md
architecture-reviewer.md
```

Use agents when you want Claude to apply a specialized review lens. For example, the security reviewer focuses on secret exposure, unsafe automation, weak access control, and public repository risk. The docs editor focuses on clarity, structure, and publication quality.

## 7. Use slash commands for common project actions

Commands live here:

```text
.claude/commands/
```

This project includes commands such as:

```text
/project-map
/repo-security-check
/blog-update
/skill-map
/new-skill
/safe-push
/pr
/review
/test
/threat-model
/incident-runbook
/docs
```

Commands are useful when you want a quick project-specific action. For example:

```text
/repo-security-check
```

asks Claude to review the repository as a public GitHub project.

```text
/blog-update
```

asks Claude to update the Dev.to article while preserving the `desertfox33` repository reference.

## 8. Use hooks carefully

Hooks live here:

```text
.claude/hooks/
```

This project includes conservative hooks:

```text
block-sensitive-writes.sh
block-dangerous-bash.sh
post-edit-format.sh
validate-code.sh
```

The hooks are intentionally limited. They block obvious dangerous patterns such as writing to `.env`, private key files, local settings, or running destructive shell commands.

Hooks are useful, but they are not a complete security control. Treat them as guardrails, not as a replacement for code review, branch protection, secret scanning, and careful GitHub Actions configuration.

## 9. Keep project rules separate

Rules live here:

```text
.claude/rules/
```

The template includes rules for:

```text
code-style.md
security.md
documentation.md
testing-standard.md
```

Rules are useful when a standard applies to a focused area. For example, documentation rules remind Claude to keep the repository link as:

```text
https://github.com/desertfox33/claude-code-project-template
```

and not to refer to any external source repository.

## 10. Use memory for project decisions

Memory files live here:

```text
.claude/memory/
```

This template includes:

```text
project-context.md
decisions.md
progress.md
```

Use memory to record durable project decisions. For this project, one important decision is that the distributed ZIP does not include `.git` metadata. That avoids branch conflicts, remote confusion, and accidental pushes to the wrong remote.

## 11. Secure the public GitHub repository

A public repository can be read and forked by anyone, but strangers cannot push to it unless you grant write access.

The real risks are:

- Accidentally committing secrets
- Accepting malicious pull requests
- Running unsafe GitHub Actions
- Giving workflows excessive permissions
- Adding untrusted dependencies
- Publishing scripts that encourage unsafe commands

The repository includes these files to support safer public collaboration:

```text
.github/CODEOWNERS
.github/pull_request_template.md
.github/dependabot.yml
.github/workflows/repository-safety.yml
SECURITY.md
CONTRIBUTING.md
.gitignore
```

After uploading to GitHub, enable these settings where available:

- Secret scanning
- Secret scanning push protection
- Dependabot alerts
- Dependabot security updates
- Dependency graph
- Branch protection or rulesets for `main`
- Restricted GitHub Actions permissions
- Required approval for outside contributors

## 12. Upload from iPad using Codespaces

The easiest iPad workflow is GitHub Codespaces.

Create a public GitHub repository:

```text
desertfox33/claude-code-project-template
```

Then open Codespaces and upload the ZIP.

Run:

```bash
unzip claude-code-project-template-desertfox33-full.zip
cd claude-code-project-template
chmod +x scripts/*.sh .claude/hooks/*.sh
./scripts/check-repo-safety.sh
```

Initialize Git:

```bash
git init
git branch -M main
git config user.name "desertfox33"
git config user.email "desertfox33@users.noreply.github.com"
git remote add origin https://github.com/desertfox33/claude-code-project-template.git
```

Commit:

```bash
git add .
git commit -m "Initial commit: full Claude Code project template"
```

If you already created a README on GitHub, pull first:

```bash
git pull origin main --allow-unrelated-histories
```

If there is a README conflict, keep the project README from this template, then run:

```bash
git add README.md
git commit -m "Resolve README conflict"
```

Push:

```bash
git config --global http.version HTTP/1.1
git push -u origin main
```

If GitHub asks for a password, use a fine-grained personal access token instead of your GitHub password.

## 13. Practical workflow after setup

For everyday work, avoid pushing directly to `main`.

Use a branch:

```bash
git checkout -b update-claude-skills
```

Make your changes, then ask Claude:

```text
Use /security-review and /testing-patterns on the current changes.
```

Run:

```bash
./scripts/check-repo-safety.sh
```

Commit and push the branch:

```bash
git add .
git commit -m "Improve Claude Code skills"
git push -u origin update-claude-skills
```

Open a pull request and use:

```text
/pr
```

to generate a clean PR description.

## Common mistakes

Do not put every instruction into `CLAUDE.md`.

Do not commit local settings.

Do not expose a real `.env` file.

Do not enable broad GitHub Actions write permissions.

Do not trust pull requests from strangers without review.

Do not copy repository references from external examples. Your public reference should be your own repository:

```text
https://github.com/desertfox33/claude-code-project-template
```

## Practical takeaway

A strong Claude Code setup is not only a prompt file. It is a working project system.

Use `CLAUDE.md` for always-loaded context. Use skills for repeatable procedures. Use agents for specialized review. Use commands for common workflows. Use hooks for limited safety automation. Use GitHub settings to protect the public repository.

That structure gives Claude enough context to help effectively while keeping control with you.
