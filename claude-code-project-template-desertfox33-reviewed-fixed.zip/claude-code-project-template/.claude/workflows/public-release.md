# Public Release Workflow

1. Run `./scripts/check-repo-safety.sh`.
2. Review `git status`.
3. Review `git diff --cached`.
4. Confirm docs reference only `desertfox33/claude-code-project-template`.
5. Confirm `.github/`, `SECURITY.md`, `CONTRIBUTING.md`, and `.gitignore` exist.
6. Push to GitHub.
7. Enable secret scanning, Dependabot, branch protection, and restricted Actions permissions.
