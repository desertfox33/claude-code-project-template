# Blog Publish Workflow

1. Open `blog/devto-claude-code-project-setup.md`.
2. Confirm front matter uses `published: false` during review.
3. Verify GitHub repository link.
4. Preview in Dev.to.
5. Check code blocks and headings.
6. Publish only after the public GitHub repository is visible and security settings are enabled.
