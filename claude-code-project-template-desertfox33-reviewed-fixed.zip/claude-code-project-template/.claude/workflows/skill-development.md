# Skill Development Workflow

1. Decide whether the logic belongs in CLAUDE.md, rules, command, agent, or skill.
2. Create `.claude/skills/<name>/SKILL.md`.
3. Write a precise description so Claude knows when to use it.
4. Add supporting references only when needed.
5. Test by invoking `/<skill-name>`.
6. Keep security-sensitive actions behind human review.
