# Secure Change Workflow

1. Understand the change.
2. Identify affected assets and trust boundaries.
3. Use `/security-review` when security-sensitive files change.
4. Use `/testing-patterns` for validation.
5. Use `/pr-description` before opening a PR.
6. Review all diffs manually before merge.
