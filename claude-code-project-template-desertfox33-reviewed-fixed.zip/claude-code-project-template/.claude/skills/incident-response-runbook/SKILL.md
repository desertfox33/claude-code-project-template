---
name: incident-response-runbook
description: Use when creating or reviewing incident response steps for security, cloud, application, or repository incidents.
---

# Incident Response Runbook

## When to use this skill

Use when creating or reviewing incident response steps for security, cloud, application, or repository incidents.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Define detection triggers.
2. Write triage and containment steps.
3. Include communication and evidence handling.
4. End with recovery and lessons learned.

## Output format

A practical runbook that an on-call engineer can follow.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
