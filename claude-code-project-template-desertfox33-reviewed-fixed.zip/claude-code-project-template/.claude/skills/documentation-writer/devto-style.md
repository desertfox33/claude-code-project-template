# Dev.to Style Notes

- Use valid front matter.
- Keep headings readable.
- Use practical examples and code blocks.
- Avoid clickbait.
- Link to the GitHub repository only after it is public.
- Keep `published: false` until final review.
