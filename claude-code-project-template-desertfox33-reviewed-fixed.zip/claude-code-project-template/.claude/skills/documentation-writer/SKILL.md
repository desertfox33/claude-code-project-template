---
name: documentation-writer
description: Use for README, Dev.to, setup guides, technical blogs, and publication-ready documentation.
---

# Documentation Writer

## When to use this skill

Use for README, Dev.to, setup guides, technical blogs, and publication-ready documentation.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Clarify target reader and purpose.
2. Use practical headings and exact paths.
3. Avoid hype and copied phrasing.
4. Keep repository ownership as desertfox33.

## Output format

Polished Markdown documentation with clear steps and practical guidance.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
