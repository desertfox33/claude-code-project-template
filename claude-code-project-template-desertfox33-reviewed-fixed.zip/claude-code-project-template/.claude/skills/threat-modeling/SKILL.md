---
name: threat-modeling
description: Use when analyzing assets, trust boundaries, attacker paths, controls, logging, and residual risk.
---

# Threat Modeling

## When to use this skill

Use when analyzing assets, trust boundaries, attacker paths, controls, logging, and residual risk.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Define assets and trust boundaries.
2. Identify realistic threat actors and attack paths.
3. Map preventive, detective, and response controls.
4. Document residual risk.

## Output format

A lightweight threat model table and remediation plan.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
