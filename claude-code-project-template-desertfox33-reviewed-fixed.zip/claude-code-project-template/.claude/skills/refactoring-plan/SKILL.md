---
name: refactoring-plan
description: Use when planning safe refactoring without changing behavior.
---

# Refactoring Plan

## When to use this skill

Use when planning safe refactoring without changing behavior.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify current behavior and constraints.
2. Plan small, reversible steps.
3. Preserve tests or add characterization tests.
4. Call out risks and rollback.

## Output format

Step-by-step refactoring plan.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
