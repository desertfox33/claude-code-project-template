---
name: pr-description
description: Use when preparing a pull request summary, merge request description, or change review note.
---

# Pull Request Description

## When to use this skill

Use when preparing a pull request summary, merge request description, or change review note.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Summarize what changed and why.
2. List affected files or components.
3. Document testing and security review.
4. Call out risks and rollback.

## Output format

A clean PR description ready to paste into GitHub.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
