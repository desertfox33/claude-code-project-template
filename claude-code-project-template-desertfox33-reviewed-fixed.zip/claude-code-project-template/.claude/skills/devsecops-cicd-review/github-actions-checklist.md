# GitHub Actions Security Checklist

- Default workflow permissions should be read-only unless needed.
- Avoid running privileged workflows on untrusted pull requests.
- Prefer pinned actions or trusted publishers.
- Do not echo secrets.
- Avoid curl|sh patterns.
- Review artifact upload/download paths.
- Require manual approval for outside contributors.
