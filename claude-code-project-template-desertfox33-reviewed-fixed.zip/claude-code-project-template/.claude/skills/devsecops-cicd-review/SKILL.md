---
name: devsecops-cicd-review
description: Use when editing or reviewing GitHub Actions, CI/CD pipelines, release scripts, or automation.
---

# DevSecOps CI/CD Review

## When to use this skill

Use when editing or reviewing GitHub Actions, CI/CD pipelines, release scripts, or automation.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Check workflow permissions.
2. Check third-party actions and pinning.
3. Check secrets exposure and PR-from-fork behavior.
4. Recommend least privilege and approval gates.

## Output format

CI/CD security review with exact safer settings.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
