---
name: docker-kubernetes-review
description: Use when reviewing Dockerfiles, Compose files, Kubernetes manifests, Helm charts, or container runtime settings.
---

# Docker Kubernetes Review

## When to use this skill

Use when reviewing Dockerfiles, Compose files, Kubernetes manifests, Helm charts, or container runtime settings.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Check image source and tags.
2. Review root user, capabilities, secrets, network exposure, and resource limits.
3. Check readiness/liveness and logging.
4. Recommend safer defaults.

## Output format

Container/Kubernetes security and reliability review.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
