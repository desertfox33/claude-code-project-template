---
name: code-review
description: Use when reviewing code changes for correctness, maintainability, reliability, and production readiness.
---

# Code Review

## When to use this skill

Use when reviewing code changes for correctness, maintainability, reliability, and production readiness.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Review the diff and changed files.
2. Identify correctness bugs, maintainability issues, edge cases, and test gaps.
3. Separate required fixes from optional improvements.
4. Avoid rewriting everything unless asked.

## Output format

Findings by severity, file/path evidence, recommended fixes, and test suggestions.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
