---
name: testing-patterns
description: Use when designing, improving, or reviewing tests for a feature, bug fix, refactor, or public repo template.
---

# Testing Patterns

## When to use this skill

Use when designing, improving, or reviewing tests for a feature, bug fix, refactor, or public repo template.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify behavior under test.
2. Choose unit, integration, regression, and security tests as appropriate.
3. Include negative and edge cases.
4. State when manual validation is needed.

## Output format

A practical test plan with commands, example test cases, and risk coverage.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
