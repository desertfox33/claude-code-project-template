---
name: performance-review
description: Use when reviewing performance-sensitive code, queries, APIs, build steps, or architecture.
---

# Performance Review

## When to use this skill

Use when reviewing performance-sensitive code, queries, APIs, build steps, or architecture.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify hotspots and unnecessary work.
2. Review caching, pagination, batching, and resource use.
3. Separate measurement from guesses.
4. Suggest practical benchmarks.

## Output format

Performance review with measurement plan.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
