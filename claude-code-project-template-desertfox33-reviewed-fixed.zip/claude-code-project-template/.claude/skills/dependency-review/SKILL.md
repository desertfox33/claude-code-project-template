---
name: dependency-review
description: Use when reviewing dependency manifests, package updates, lock files, and supply-chain risk.
---

# Dependency Review

## When to use this skill

Use when reviewing dependency manifests, package updates, lock files, and supply-chain risk.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify direct and transitive dependency risk.
2. Check maintainer trust and update scope.
3. Recommend pinning, lock files, and Dependabot strategy.
4. Flag risky install scripts.

## Output format

Dependency risk review with next actions.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
