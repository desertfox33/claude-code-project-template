# Security Review Checklist

- Secrets and credentials
- Dangerous scripts
- GitHub Actions permissions
- Pull request from fork behavior
- Dependency and supply-chain risk
- Public repository metadata
- Logging of sensitive information
- Least privilege
- Branch protection
- Signed commits if configured
