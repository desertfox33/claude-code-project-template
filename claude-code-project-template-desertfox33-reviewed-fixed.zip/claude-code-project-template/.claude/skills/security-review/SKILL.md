---
name: security-review
description: Use for defensive review of code, scripts, GitHub configuration, public repository safety, credentials, hooks, and automation.
---

# Security Review

## When to use this skill

Use for defensive review of code, scripts, GitHub configuration, public repository safety, credentials, hooks, and automation.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify protected assets.
2. Identify likely attack paths or misuse paths.
3. Check for secrets, unsafe scripts, broad permissions, and malicious injection opportunities.
4. Recommend practical controls and residual risk.

## Output format

Security findings with severity, evidence, remediation, and residual risk.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
