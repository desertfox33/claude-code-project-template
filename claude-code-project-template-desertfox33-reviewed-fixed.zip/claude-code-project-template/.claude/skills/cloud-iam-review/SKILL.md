---
name: cloud-iam-review
description: Use when reviewing AWS, Azure, GCP, or GitHub IAM examples for least privilege and operational risk.
---

# Cloud IAM Review

## When to use this skill

Use when reviewing AWS, Azure, GCP, or GitHub IAM examples for least privilege and operational risk.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Identify principals, permissions, resources, and conditions.
2. Flag wildcard permissions and long-lived credentials.
3. Recommend role-based, scoped, auditable access.
4. Include logging and rotation guidance.

## Output format

IAM review with least-privilege recommendations.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
