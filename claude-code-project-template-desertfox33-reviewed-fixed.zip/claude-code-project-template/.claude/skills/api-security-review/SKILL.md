---
name: api-security-review
description: Use when reviewing APIs, service boundaries, authentication, authorization, input validation, and logging.
---

# API Security Review

## When to use this skill

Use when reviewing APIs, service boundaries, authentication, authorization, input validation, and logging.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Check authn/authz boundaries.
2. Review input validation and output handling.
3. Consider rate limits, abuse paths, and audit logs.
4. Identify tests for security cases.

## Output format

API security checklist and findings.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
