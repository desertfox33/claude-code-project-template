---
name: architecture-review
description: Use when reviewing technical design, boundaries, dependencies, operational failure modes, and trade-offs.
---

# Architecture Review

## When to use this skill

Use when reviewing technical design, boundaries, dependencies, operational failure modes, and trade-offs.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Map components and data flows.
2. Identify failure modes and bottlenecks.
3. Review security and observability boundaries.
4. Recommend incremental improvements.

## Output format

Architecture review with risks and trade-offs.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
