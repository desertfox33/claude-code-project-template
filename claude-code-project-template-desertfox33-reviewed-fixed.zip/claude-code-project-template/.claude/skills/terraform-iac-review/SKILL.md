---
name: terraform-iac-review
description: Use when reviewing Terraform, IaC, infrastructure modules, cloud resources, or policy-as-code.
---

# Terraform IaC Review

## When to use this skill

Use when reviewing Terraform, IaC, infrastructure modules, cloud resources, or policy-as-code.

## Inputs to request or inspect

- User goal or change request
- Relevant files and diffs
- Existing tests, docs, or configuration
- Security or operational constraints

## Procedure

1. Check state, secrets, IAM, public exposure, and destructive changes.
2. Review variable defaults and outputs.
3. Recommend policy checks and plan review.
4. Consider rollback and drift.

## Output format

IaC review with safety checks and remediation.

## Guardrails

- Do not invent product behavior, versions, vulnerabilities, or standards.
- Do not expose secrets or ask the user to paste private tokens.
- For public repository work, verify that examples reference `desertfox33/claude-code-project-template`.
- Clearly separate facts, assumptions, and recommendations.
