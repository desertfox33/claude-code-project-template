# Testing Standard

For code changes, recommend tests at the right level:

- Unit tests for isolated logic.
- Integration tests for boundaries and service behavior.
- Security tests for authorization, input validation, and secret handling.
- Regression tests for bug fixes.
- Smoke tests for deployment or CLI workflows.

When tests cannot be run, clearly say what was reviewed and what still needs validation.
