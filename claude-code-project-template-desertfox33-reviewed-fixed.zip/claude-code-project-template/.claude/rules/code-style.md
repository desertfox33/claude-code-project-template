# Code Style Rules

Use these rules when editing application code.

- Prefer clear, boring, maintainable code over clever abstractions.
- Explain non-obvious trade-offs in comments, not obvious syntax.
- Keep functions focused and testable.
- Validate inputs at trust boundaries.
- Avoid logging secrets, tokens, passwords, session identifiers, or private user data.
- Do not introduce dependencies without explaining why the dependency is needed and how it is maintained.
