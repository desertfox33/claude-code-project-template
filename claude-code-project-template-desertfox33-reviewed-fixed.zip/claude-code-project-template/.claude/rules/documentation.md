# Documentation Rules

Use these rules when editing Markdown, README files, or blog content.

- Write in a practical professional tone.
- Avoid hype and generic intros.
- Use exact file paths and commands where helpful.
- Separate facts, assumptions, and recommendations.
- Link to `https://github.com/desertfox33/claude-code-project-template` as the project repository.
- Do not refer to external source repositories as the project origin.
