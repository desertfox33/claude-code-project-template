# Security Rules

Apply these rules for all repository changes.

- Treat this as a public repository.
- Never commit secrets or local settings.
- Use least privilege for examples involving IAM, tokens, or GitHub Actions.
- For scripts, avoid downloading and executing remote content.
- For GitHub Actions, prefer read-only permissions unless write access is required.
- For hooks, block obvious unsafe actions but do not claim hooks replace human review.
- For AI usage, include human review for security-sensitive decisions.
