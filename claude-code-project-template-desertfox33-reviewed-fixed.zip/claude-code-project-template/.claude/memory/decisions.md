# Decisions

## Repository ownership

All examples and links must use `desertfox33/claude-code-project-template`.

## Security posture

The repository is public. It must avoid secrets, local credentials, destructive automation, and unsafe GitHub Actions defaults.

## Git metadata

The distributed ZIP does not include `.git` metadata. Users initialize Git locally to avoid branch and remote conflicts.
