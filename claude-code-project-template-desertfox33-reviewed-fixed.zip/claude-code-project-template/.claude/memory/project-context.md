# Project Context

Repository: `desertfox33/claude-code-project-template`

Purpose: Provide a secure, full-featured Claude Code project template with reusable skills, agents, commands, hooks, memory, GitHub security files, and Dev.to documentation.

Audience:
- Developers learning Claude Code project structure
- Security-minded engineers publishing public repositories
- Technical writers documenting AI-assisted development workflows
