# Blog Update

Edit or review `blog/devto-claude-code-project-setup.md`.

Goals:
- Make the article detailed and practical
- Explain where Claude project files live
- Explain which skills to use and when
- Explain public GitHub security settings
- Keep repository ownership as desertfox33
- Avoid references to external source repositories
- Keep Dev.to Markdown front matter valid
