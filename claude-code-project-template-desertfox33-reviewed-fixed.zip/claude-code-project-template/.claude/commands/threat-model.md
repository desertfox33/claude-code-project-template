# Threat Model

Create a lightweight threat model.

Include:
- Asset
- Trust boundary
- Threat actor
- Attack path
- Control
- Detection/logging
- Residual risk
