# Repository Security Check

Review this repository as a public GitHub project.

Check:
- Secrets and local-only files
- `.gitignore`
- GitHub Actions permissions
- Dependabot configuration
- CODEOWNERS
- SECURITY.md
- CONTRIBUTING.md
- Pull request template
- Suspicious scripts or commands
- References to repositories other than desertfox33/claude-code-project-template

Return:
1. Pass/fail summary
2. Findings
3. Exact remediation steps
