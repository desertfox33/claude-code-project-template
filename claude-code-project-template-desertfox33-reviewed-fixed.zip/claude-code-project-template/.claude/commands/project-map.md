# Project Map

Analyze this Claude Code project and explain:

1. What each major folder does
2. Which skills are available
3. Which agents are available
4. Which hooks are configured
5. How a new user should start using the repo
6. Any missing or risky configuration
