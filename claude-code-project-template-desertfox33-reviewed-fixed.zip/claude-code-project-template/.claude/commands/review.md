# Review

Perform a practical review of the current change set.

Use:
- Code quality lens
- Security lens
- Testing lens
- Documentation lens
- Public repo safety lens
