# Pull Request Assistant

Create a PR summary with:
- Summary
- Why this change matters
- Files changed
- Testing performed
- Security review
- Risks and rollback
