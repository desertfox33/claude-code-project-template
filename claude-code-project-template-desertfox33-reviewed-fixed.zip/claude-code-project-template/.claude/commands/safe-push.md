# Safe GitHub Push

Help push this repository safely to:
`https://github.com/desertfox33/claude-code-project-template`

Steps:
1. Check branch
2. Check remote
3. Check secrets
4. Resolve GitHub README conflicts if needed
5. Use HTTPS token if SSH is not configured
6. Push to main
7. Recommend branch protection and secret scanning
