# New Skill Builder

Help create a new Claude Code skill.

Ask for:
- Skill name
- Trigger situation
- Inputs needed
- Step-by-step workflow
- Required supporting files
- Tools the skill may use
- Security limitations

Then create `.claude/skills/<skill-name>/SKILL.md` and any supporting files.
