# Test Planner

Create a test plan for the current change.

Include:
- Unit tests
- Integration tests
- Security checks
- Manual validation
- Commands to run
