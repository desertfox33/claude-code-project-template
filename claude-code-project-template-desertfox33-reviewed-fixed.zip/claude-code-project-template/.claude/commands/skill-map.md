# Skill Map

Inspect `.claude/skills/` and produce a reader-friendly table with:
- Skill name
- Slash command
- When to use it
- What files it may inspect
- Expected output
- Security cautions
