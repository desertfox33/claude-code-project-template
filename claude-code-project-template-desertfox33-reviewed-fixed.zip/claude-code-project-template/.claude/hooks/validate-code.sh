#!/usr/bin/env bash
set -euo pipefail

echo "Validation checklist:"
echo "- Run project tests if code changed."
echo "- Run scripts/check-repo-safety.sh before public push."
echo "- Review Git diff before commit."
