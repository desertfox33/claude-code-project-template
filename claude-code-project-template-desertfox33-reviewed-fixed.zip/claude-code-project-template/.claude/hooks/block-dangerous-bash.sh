#!/usr/bin/env bash
set -euo pipefail

# Claude Code passes hook input as JSON on stdin. Keep the payload in a variable and
# parse it from the environment so the Python parser does not accidentally consume
# a here-doc instead of the hook payload.
payload="$(cat || true)"

command_text="$(
  CLAUDE_HOOK_PAYLOAD="$payload" python3 - <<'PY' 2>/dev/null || true
import json
import os
import sys

try:
    data = json.loads(os.environ.get("CLAUDE_HOOK_PAYLOAD", ""))
except Exception:
    sys.exit(0)

commands = []

def walk(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"command", "cmd", "bash_command"} and isinstance(child, str):
                commands.append(child)
            else:
                walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)

walk(data)
print("\n".join(commands))
PY
)"

# Block commands that are destructive, hard to roll back, or commonly used to pipe
# unreviewed remote code into a shell. These checks are intentionally conservative.
dangerous_patterns=(
  '(^|[;&|[:space:]])rm[[:space:]]+-[^[:space:]]*r[^[:space:]]*f[[:space:]]+(/|~|\$HOME|\.\.)([[:space:]]|$)'
  '(^|[;&|[:space:]])git[[:space:]]+push[[:space:]].*--force'
  '(^|[;&|[:space:]])git[[:space:]]+reset[[:space:]]+--hard'
  '(^|[;&|[:space:]])git[[:space:]]+clean[[:space:]]+-[^[:space:]]*([xXfFdD])[^[:space:]]*'
  '(^|[;&|[:space:]])chmod[[:space:]]+(-R[[:space:]]+)?777([[:space:]]|$)'
  '(^|[;&|[:space:]])sudo[[:space:]]+'
  '(^|[;&|[:space:]])dd[[:space:]].*of=/dev/'
  '(^|[;&|[:space:]])mkfs(\.|[[:space:]])'
  '(curl|wget)[^|;&]*(\||>)[[:space:]]*(sudo[[:space:]]+)?(sh|bash|zsh|python|python3)([[:space:]]|$)'
  'bash[[:space:]]+-c[[:space:]]+["'\'']?\$\(curl'
  'bash[[:space:]]+-c[[:space:]]+["'\'']?\$\(wget'
)

for pattern in "${dangerous_patterns[@]}"; do
  if printf '%s\n' "$command_text" | grep -Eiq "$pattern"; then
    echo "Blocked: risky shell command detected by pattern: $pattern" >&2
    echo "Explain the impact and get explicit user approval before using destructive or remote-execution commands." >&2
    exit 2
  fi
done

exit 0
