#!/usr/bin/env bash
set -euo pipefail

# Conservative safety hook. It reads Claude Code hook JSON from stdin when available
# and blocks edits to obvious secret, credential, and local-only files.
payload="$(cat || true)"

target_paths="$(
  CLAUDE_HOOK_PAYLOAD="$payload" python3 - <<'PY' 2>/dev/null || true
import json
import os
import sys

try:
    data = json.loads(os.environ.get("CLAUDE_HOOK_PAYLOAD", ""))
except Exception:
    sys.exit(0)

candidates = []

def walk(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"file_path", "path", "filename", "target_file"} and isinstance(child, str):
                candidates.append(child)
            else:
                walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)

walk(data)
print("\n".join(candidates))
PY
)"

blocked_regex='(^|/)(\.env($|\.)|secrets?/|credentials?/|CLAUDE\.local\.md$|settings\.local\.json$|\.mcp\.json$|id_rsa|id_ed25519|.*private.*key.*|.*\.pem$|.*\.p12$|.*\.pfx$|.*\.key$)'

if printf '%s\n' "$target_paths" | grep -Eiq "$blocked_regex"; then
  echo "Blocked: attempted write/edit to a sensitive or local-only file." >&2
  echo "Use example files such as .env.example, .mcp.example.json, or settings.local.json.example instead." >&2
  exit 2
fi

exit 0
