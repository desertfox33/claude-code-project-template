#!/usr/bin/env bash
set -euo pipefail

# Safe post-edit hook. It does not install dependencies or modify files.
# It only prints a reminder when common documentation/configuration files change.

payload="$(cat || true)"

changed_paths="$(printf '%s' "$payload" | python3 - <<'PY' 2>/dev/null || true
import json,sys
try:
    data=json.load(sys.stdin)
except Exception:
    sys.exit(0)
candidates=[]
def walk(x):
    if isinstance(x, dict):
        for k,v in x.items():
            if k in {"file_path","path","filename","target_file"} and isinstance(v,str):
                candidates.append(v)
            else:
                walk(v)
    elif isinstance(x, list):
        for i in x: walk(i)
walk(data)
print("\n".join(candidates))
PY
)"

if printf '%s\n' "$changed_paths" | grep -Eq '\.(md|json|yml|yaml|sh)$'; then
  echo "Reminder: review formatting, links, and secrets before committing changed docs/config/scripts." >&2
fi

exit 0
