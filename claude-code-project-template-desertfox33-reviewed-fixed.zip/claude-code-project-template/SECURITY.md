# Security Policy

This is a public repository owned by **desertfox33**.

## Supported scope

This repository contains Claude Code project templates, documentation, skills, hooks, commands, agents, and GitHub configuration examples.

## Reporting a vulnerability

If you find a security issue, do not publish exploit details in a public issue.

Open a private security advisory on GitHub if available, or contact the repository owner through the available GitHub profile contact method.

## Do not report

- Requests for real credentials
- Attempts to test malicious payloads against third-party systems
- Offensive exploitation walkthroughs

## Repository safety expectations

Contributions must not include:

- Secrets, credentials, tokens, or private keys
- Malicious scripts
- Obfuscated code
- Unsafe GitHub Actions permissions
- References to repositories other than `desertfox33/claude-code-project-template` as the project source


## Before public release

Run the repository safety check before pushing:

```bash
./scripts/check-repo-safety.sh
```

The check is expected to fail on likely secrets, private local configuration such as `.mcp.json`, large binary/archive files, and dangerous script patterns. Treat failures as release blockers unless a maintainer documents a reviewed exception.
