#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${1:-https://github.com/desertfox33/claude-code-project-template.git}"

if [ -d .git ]; then
  echo "Existing .git directory detected."
else
  git init
fi

git branch -M main
git config user.name "desertfox33"
git config user.email "desertfox33@users.noreply.github.com"

git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"

echo "Repository initialized for:"
git remote -v
echo
echo "Next:"
echo "  git add ."
echo "  git commit -m 'Initial commit: Claude Code project template'"
echo "  git pull origin main --allow-unrelated-histories   # only if GitHub repo already has README"
echo "  git push -u origin main"
