#!/usr/bin/env bash
set -euo pipefail

echo "Checking repository for public-release safety issues..."

python3 - <<'PY'
from __future__ import annotations

import math
import os
import re
import sys
from pathlib import Path

ROOT = Path(".").resolve()
EXCLUDED_DIRS = {
    ".git",
    "node_modules",
    "dist",
    "build",
    "coverage",
    ".next",
    ".nuxt",
    "venv",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    ".cache",
}

SENSITIVE_NAME_RE = re.compile(
    r"(^|/)(\.env($|\.)|secrets?/|credentials?/|CLAUDE\.local\.md$|"
    r"\.mcp\.json$|settings\.local\.json$|id_rsa|id_ed25519|"
    r".*private.*key.*|.*\.(pem|p12|pfx|key)$)",
    re.IGNORECASE,
)

SECRET_PATTERNS = [
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{36,}\b")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |OPENSSH |EC |DSA |)?PRIVATE KEY-----")),
    (
        "Generic assigned secret",
        re.compile(
            r"(?i)\b(api[_-]?key|secret|token|password|private[_-]?key)\b"
            r"\s*[:=]\s*['\"]?([A-Za-z0-9_./+=:-]{20,})"
        ),
    ),
]

DANGEROUS_SCRIPT_PATTERNS = [
    ("remote code piped to shell", re.compile(r"(curl|wget)[^|;&]*(\||>)\s*(sudo\s+)?(sh|bash|zsh|python3?)", re.I)),
    ("recursive force delete of root/home/parent", re.compile(r"\brm\s+-[^\n]*r[^\n]*f\s+(/|~|\$HOME|\.\.)", re.I)),
    ("force push", re.compile(r"\bgit\s+push\b[^\n]*--force", re.I)),
    ("hard reset", re.compile(r"\bgit\s+reset\s+--hard\b", re.I)),
    ("chmod 777", re.compile(r"\bchmod\s+(-R\s+)?777\b", re.I)),
]

def iter_files() -> list[Path]:
    paths: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel_parts = path.relative_to(ROOT).parts
        if any(part in EXCLUDED_DIRS for part in rel_parts):
            continue
        paths.append(path)
    return paths

def is_example(path: Path) -> bool:
    name = path.name.lower()
    return name.endswith(".example") or name.endswith(".example.json") or name.endswith(".example.md") or name == ".mcp.example.json"

def is_text(path: Path) -> bool:
    try:
        path.read_text(encoding="utf-8")
        return True
    except UnicodeDecodeError:
        return False
    except OSError:
        return False

def shannon_entropy(value: str) -> float:
    if not value:
        return 0.0
    counts = {char: value.count(char) for char in set(value)}
    return -sum((count / len(value)) * math.log2(count / len(value)) for count in counts.values())

findings: list[str] = []
files = iter_files()

for path in files:
    rel = path.relative_to(ROOT).as_posix()

    if SENSITIVE_NAME_RE.search(rel) and not is_example(path):
        findings.append(f"Sensitive or local-only filename should not be committed: {rel}")

    if path.stat().st_size > 25 * 1024 * 1024:
        findings.append(f"Large file over 25MB should not be committed: {rel}")

    if re.search(r"\.(zip|mp4|mov|m4v|tar|gz|tgz)$", rel, re.I):
        findings.append(f"Archive/media file should not be committed to template repo: {rel}")

    if not is_text(path):
        continue

    text = path.read_text(encoding="utf-8", errors="ignore")
    for label, pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text):
            candidate = match.group(match.lastindex or 0)
            # Avoid noisy matches on documentation placeholders; real tokens tend to
            # be both long and high entropy.
            if label == "Generic assigned secret" and shannon_entropy(candidate) < 3.5:
                continue
            findings.append(f"{label} candidate in {rel}")

    if rel.endswith(".sh") or rel.startswith(".github/workflows/"):
        for label, pattern in DANGEROUS_SCRIPT_PATTERNS:
            if path.as_posix().endswith(("block-dangerous-bash.sh", "check-repo-safety.sh")):
                continue
            if pattern.search(text):
                findings.append(f"Dangerous script pattern ({label}) in {rel}")

if findings:
    print("\nPublic-release safety check FAILED:\n")
    for finding in sorted(set(findings)):
        print(f"- {finding}")
    print("\nFix these findings or document a reviewed exception before pushing.")
    sys.exit(1)

print("Public-release safety check passed.")
PY
