#!/usr/bin/env bash
set -euo pipefail

echo "Claude project assets:"
find .claude -maxdepth 3 -type f | sort
