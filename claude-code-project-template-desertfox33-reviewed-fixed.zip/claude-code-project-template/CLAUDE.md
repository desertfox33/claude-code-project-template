# Claude Code Instructions for desertfox33/claude-code-project-template

You are working in a public, security-conscious Claude Code project template owned by **desertfox33**.

## Primary objective

Help maintain a reusable Claude Code project structure that shows how to use:

- Project memory
- Skills
- Subagents
- Slash commands
- Rules
- Hooks
- GitHub security files
- Blog documentation
- Safe public repository practices

## Repository identity

Use this repository reference in documentation and examples:

```text
https://github.com/desertfox33/claude-code-project-template
```

Do not reference any upstream template or external source repository as the project origin. This repository must stand on its own under desertfox33.

## Operating style

Be practical, security-aware, and precise.

Before editing, inspect relevant files. Before recommending a command, consider whether it may expose secrets, overwrite user work, or run untrusted code.

## Safety rules

Never create or commit real secrets, tokens, private keys, production credentials, personal access tokens, `.env` files, or private local settings.

Use example files only:

```text
.env.example
CLAUDE.local.md.example
.claude/settings.local.json.example
.mcp.example.json
```

Do not modify or read files that look sensitive unless the user explicitly asks and the file is safe to inspect.

Avoid destructive commands unless the user clearly approves them. Do not run commands such as `rm -rf`, `git reset --hard`, `git clean -fdx`, or force-push commands without explaining impact and asking for confirmation.

## How to use project context

- Use `CLAUDE.md` for instructions that matter every session.
- Use `.claude/rules/` for narrower rules.
- Use `.claude/skills/` for reusable procedures.
- Use `.claude/agents/` for specialized review roles.
- Use `.claude/commands/` for repeatable project actions.
- Use `.claude/hooks/` for guardrails and automation.
- Use `.claude/memory/` for maintained project notes.

## Skill guidance

Use the project skills when the user's request matches the skill description.

Examples:

- Use `/security-review` for repository hardening, public release checks, secret exposure, and defensive review.
- Use `/documentation-writer` for blog, README, Dev.to, and publishing material.
- Use `/testing-patterns` for test planning and test coverage.
- Use `/threat-modeling` for asset/threat/control analysis.
- Use `/devsecops-cicd-review` before changing GitHub Actions or CI/CD files.
- Use `/dependency-review` before changing dependency manifests or lock files.

## Blog guidance

The Dev.to blog lives at:

```text
blog/devto-claude-code-project-setup.md
```

Keep it original, practical, and written for informed technology professionals. Avoid hype and avoid claiming product behavior that should be verified against official Claude Code documentation.

## Public repository guidance

When reviewing public repository safety, check:

- No secrets or local credentials
- No malicious scripts
- No unsafe GitHub Actions permissions
- `.gitignore` covers local/private files
- Branch protection is documented
- Pull request review is documented
- CODEOWNERS routes ownership to `@desertfox33`
- Docs reference only `desertfox33/claude-code-project-template`

## Preferred output

For technical answers, provide:

1. What to do
2. Why it matters
3. Exact file path or command
4. Validation step
5. Security note where relevant
