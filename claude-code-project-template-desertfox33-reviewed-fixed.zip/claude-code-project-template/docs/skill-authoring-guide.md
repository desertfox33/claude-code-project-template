# Skill Authoring Guide

A skill should be narrow, useful, and easy to audit.

## Required structure

```text
.claude/skills/my-skill/
└── SKILL.md
```

## Required frontmatter

```markdown
---
name: my-skill
description: Use this skill when...
---
```

## Good descriptions

A good description tells Claude exactly when to use the skill.

Weak:

```text
Helps with code.
```

Better:

```text
Use this skill when reviewing code changes for correctness, security, reliability, maintainability, test coverage, and production readiness.
```

## Design rules

- One job per skill.
- Keep the main `SKILL.md` concise.
- Move long references into separate files.
- Avoid hidden network behavior.
- Review any scripts before use.
- Test the skill with real tasks and improve it based on failures.
