# Claude Project Usage Guide

## What belongs where

| Location | Purpose |
|---|---|
| `CLAUDE.md` | Always-loaded project instructions |
| `CLAUDE.local.md` | Private local preferences, not committed |
| `.claude/settings.json` | Shared permissions, hooks, and project settings |
| `.claude/settings.local.json` | Private local settings, not committed |
| `.claude/skills/<name>/SKILL.md` | Reusable procedures Claude can invoke |
| `.claude/agents/*.md` | Specialized subagents |
| `.claude/commands/*.md` | Slash command prompts |
| `.claude/rules/*.md` | Scoped standards and rules |
| `.claude/hooks/*.sh` | Automation and guardrails |
| `.claude/memory/*.md` | Project notes and decisions |

## Effective usage pattern

Start with:

```text
Read CLAUDE.md and summarize the project operating model.
```

Then ask:

```text
Use /project-map to show the skills, agents, commands, hooks, and rules.
```

For a code change:

```text
Plan the change first. Then use /testing-patterns and /security-review before creating a PR.
```

For documentation:

```text
Use /documentation-writer to update the Dev.to blog and README.
```

For public release:

```text
Use /repo-security-check and run ./scripts/check-repo-safety.sh.
```
