# Public Repository Security Checklist

Use this checklist after the first push to GitHub.

## GitHub repository settings

Enable where available:

- Secret scanning
- Secret scanning push protection
- Dependabot alerts
- Dependabot security updates
- Dependency graph
- CodeQL or default code scanning if applicable

## Branch protection / rulesets

Protect `main`:

- Require pull request before merge
- Require at least one approval
- Dismiss stale approvals
- Require conversation resolution
- Block force pushes
- Restrict deletions
- Require status checks after workflows are stable
- Require signed commits after you configure SSH or GPG signing

## Actions settings

Use conservative settings:

- Workflow permissions: read-only by default
- Require approval for outside collaborators
- Do not expose secrets to pull requests from forks
- Review third-party actions before use

## Ongoing workflow

- Work on branches
- Open pull requests
- Review diffs
- Run the safety script
- Merge only after checks pass
