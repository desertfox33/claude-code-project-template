# Push This Repository from iPad to GitHub as `desertfox33`

This guide assumes you want a public GitHub repository named:

```text
https://github.com/desertfox33/claude-code-project-template
```

You have not added SSH or GPG keys yet. That is fine for the first upload. Use HTTPS with a short-lived fine-grained personal access token, then improve signing and SSH later.

## 1. Create the GitHub repository

1. Open GitHub in Safari.
2. Sign in as `desertfox33`.
3. Tap **+**.
4. Select **New repository**.
5. Owner: `desertfox33`.
6. Repository name: `claude-code-project-template`.
7. Visibility: **Public**.
8. Do not initialize with README, `.gitignore`, or license if you are uploading this template.
9. Tap **Create repository**.

## 2. Recommended iPad upload method: GitHub Codespaces

1. Open the new empty repository.
2. Tap **Code**.
3. Open **Codespaces**.
4. Create a codespace.
5. Upload this ZIP file into the Codespaces workspace.
6. Open the terminal.

Unzip and prepare the project:

```bash
unzip claude-code-project-template-desertfox33.zip
cd claude-code-project-template
```

If you want a clean Git history, remove the embedded `.git` folder and initialize again:

```bash
rm -rf .git
git init
git branch -M main
git config user.name "desertfox33"
git config user.email "YOUR_VERIFIED_GITHUB_EMAIL"
git add .
git commit -m "Initial commit: Claude Code project template"
git remote add origin https://github.com/desertfox33/claude-code-project-template.git
git push -u origin main
```

## 3. Authenticate without SSH

Because SSH is not configured yet, use HTTPS.

GitHub does not use your normal account password for Git pushes. Create a fine-grained personal access token:

1. GitHub profile photo.
2. **Settings**.
3. **Developer settings**.
4. **Personal access tokens**.
5. **Fine-grained tokens**.
6. **Generate new token**.
7. Token name: `ipad-upload-claude-template`.
8. Resource owner: `desertfox33`.
9. Repository access: only `claude-code-project-template`.
10. Permissions:
    - Contents: Read and write
    - Metadata: Read-only
11. Expiration: 7 or 30 days.
12. Generate and copy the token.

When Git asks for credentials:

```text
Username: desertfox33
Password: paste the token, not your GitHub password
```

After the first push, revoke the token if you do not need it anymore.

## 4. Secure the public repository

A public repository does not allow strangers to push directly unless you grant them access. The bigger risks are leaked secrets, malicious pull requests, unsafe automation, and accidental direct changes to `main`.

Apply these settings after the first push.

### Account security

Enable two-factor authentication for `desertfox33`.

### Code security and analysis

Open:

```text
Repository → Settings → Code security and analysis
```

Enable what is available for your account:

- Dependency graph
- Dependabot alerts
- Dependabot security updates
- Secret scanning
- Secret scanning push protection

### Protect the `main` branch

Open:

```text
Repository → Settings → Rules → Rulesets
```

Create a branch ruleset:

```text
Ruleset name: Protect main
Enforcement: Active
Target branch: main
```

Recommended rules:

- Require a pull request before merging
- Require at least one approval, even if you are the reviewer
- Dismiss stale approvals when new commits are pushed
- Require conversation resolution before merging
- Block force pushes
- Restrict branch deletion
- Require linear history
- Require status checks after you add workflows
- Require signed commits after you configure signing

### GitHub Actions safety

Open:

```text
Repository → Settings → Actions → General
```

Recommended settings:

- Workflow permissions: Read repository contents permission
- Require approval for workflows from outside contributors
- Do not expose secrets to pull requests from forks
- Review any workflow before enabling it

## 5. Check for secrets before every push

Run this before publishing:

```bash
find . -type f \( -name "*.env" -o -name "*secret*" -o -name "*token*" -o -name "*key*" \)
grep -RInE "api[_-]?key|secret|token|password|PRIVATE KEY|BEGIN RSA|BEGIN OPENSSH" . --exclude-dir=.git
```

Do not commit:

- Real `.env` files
- API tokens
- Cloud credentials
- Private SSH keys
- GPG private keys
- Production URLs that should remain private
- Personal paths in `CLAUDE.local.md`
- Local Claude settings in `.claude/settings.local.json`

Use example files instead:

- `.env.example`
- `CLAUDE.local.md.example`
- `.claude/settings.local.json.example`

## 6. Add SSH later

From a trusted terminal:

```bash
ssh-keygen -t ed25519 -C "YOUR_VERIFIED_GITHUB_EMAIL"
cat ~/.ssh/id_ed25519.pub
```

Upload only the public key to GitHub:

```text
GitHub → Settings → SSH and GPG keys → New SSH key
```

Never upload the private key.

## 7. Add commit signing later

Commit signing is useful, but it does not have to block the first upload.

Later, configure either:

- SSH commit signing
- GPG commit signing

After signing is working, enable **Require signed commits** in your repository ruleset.

## 8. Safe contribution workflow

Use this model for public contributions:

```text
Public user forks repo → opens pull request → you review diff → checks pass → you merge
```

Do not give write access to unknown contributors.

For your own work:

```bash
git checkout -b update-docs
# edit files
git add .
git commit -m "Update documentation"
git push -u origin update-docs
```

Then open a pull request into `main`.
