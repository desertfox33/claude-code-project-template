# iPad GitHub Upload Guide for desertfox33

This guide assumes the public repository is:

```text
https://github.com/desertfox33/claude-code-project-template
```

## Recommended method: GitHub Codespaces

1. Create the repository on GitHub under `desertfox33`.
2. Choose **Public**.
3. If you already created a README, expect a first-time merge conflict.
4. Open **Code → Codespaces → Create codespace on main**.
5. Upload this ZIP into Codespaces.
6. Unzip it.

```bash
unzip claude-code-project-template-desertfox33-full.zip
cd claude-code-project-template
```

## Initialize Git

This ZIP intentionally does not include `.git` metadata.

```bash
git init
git branch -M main
git config user.name "desertfox33"
git config user.email "desertfox33@users.noreply.github.com"
git remote add origin https://github.com/desertfox33/claude-code-project-template.git
```

## Check safety

```bash
chmod +x scripts/*.sh .claude/hooks/*.sh
./scripts/check-repo-safety.sh
```

## Commit

```bash
git add .
git commit -m "Initial commit: full Claude Code project template"
```

## If GitHub already has README

```bash
git pull origin main --allow-unrelated-histories
```

If README conflicts, keep the project README from this template, then:

```bash
git add README.md
git commit -m "Resolve README conflict"
```

## Push

```bash
git config --global http.version HTTP/1.1
git push -u origin main
```

## If HTTPS asks for password

Use a GitHub fine-grained personal access token, not your GitHub password.

Minimum token permissions:

```text
Repository: desertfox33/claude-code-project-template
Contents: Read and write
Metadata: Read-only
```
