# Project Structure Notes

This repository implements a complete Claude Code project structure with:

- Root project instructions in `CLAUDE.md`
- Local-only override examples
- Shared settings and safe permissions
- Reusable skills under `.claude/skills/`
- Specialized subagents under `.claude/agents/`
- Custom slash commands under `.claude/commands/`
- Conservative hooks under `.claude/hooks/`
- Rules, memory, and workflows
- GitHub repository security files
- Dev.to blog content

The project source of record is:

```text
https://github.com/desertfox33/claude-code-project-template
```
