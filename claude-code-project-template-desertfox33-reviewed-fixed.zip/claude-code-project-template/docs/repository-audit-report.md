# Repository Audit Report

## Initial critique

| Severity | Finding | Risk | Correction |
|---|---|---|---|
| High | Claude hook scripts attempted to parse JSON from stdin while also using a shell here-doc for the Python parser. | The guardrail scripts could receive an empty payload and fail open, allowing risky shell commands or sensitive-file edits. | Reworked hook parsing to pass the original hook payload through an environment variable and parse that safely from Python. |
| High | `scripts/check-repo-safety.sh` printed likely findings but always exited successfully. | CI could pass even when a secret, local config file, or oversized artifact was present. | Replaced the check with a fail-closed scanner that exits non-zero on release-blocking findings. |
| Medium | `.mcp.json` was committed as a real config file, even though MCP configs are often local and may contain sensitive commands or environment references. | Future edits could accidentally commit credentials, local paths, or sensitive server configuration. | Removed `.mcp.json`, retained `.mcp.example.json`, and added `.mcp.json` to `.gitignore` and hook deny rules. |
| Medium | Dangerous shell detection covered only a narrow set of destructive commands. | Common variants such as `sudo`, `dd of=/dev/*`, `mkfs`, remote-code piping, and broader recursive deletion patterns could bypass the hook. | Expanded pattern coverage in the Bash hook and repository safety scanner. |
| Medium | Documentation did not clearly state that `.mcp.json` must remain local-only. | Contributors may misunderstand which MCP file is safe to commit. | Added MCP safety guidance to `README.md` and release-blocking guidance to `SECURITY.md`. |
| Low | Shared Claude permissions blocked some sensitive file reads but did not explicitly cover `.mcp.json` or recursive secret paths consistently. | Claude Code users may accidentally inspect local-only configuration or nested secrets. | Added explicit `.mcp.json` and recursive secret/environment deny entries. |

## Corrections applied

- Fixed `.claude/hooks/block-dangerous-bash.sh`.
- Fixed `.claude/hooks/block-sensitive-writes.sh`.
- Replaced `scripts/check-repo-safety.sh` with a fail-closed Python-backed scanner.
- Removed committed `.mcp.json`.
- Updated `.gitignore`.
- Updated `.claude/settings.json`.
- Updated `README.md`.
- Updated `SECURITY.md`.

## Validation performed

- Confirmed the dangerous Bash hook blocks sample risky commands.
- Confirmed the sensitive-write hook blocks sample `.env` and `.mcp.json` edits.
- Confirmed `scripts/check-repo-safety.sh` passes after the corrections.
- Confirmed the repository no longer contains a committed `.mcp.json`.

## Residual recommendations

- Add branch protection in GitHub: required PR review, CODEOWNERS review, and required `Repository Safety Check`.
- Consider adding a dedicated secret-scanning tool such as GitHub Advanced Security secret scanning, Gitleaks, or TruffleHog in CI.
- Add shellcheck in CI for hook and script quality if the repository starts accepting more shell automation.
- Keep Claude hooks as defense-in-depth only; do not treat model or hook logic as the sole security boundary.
