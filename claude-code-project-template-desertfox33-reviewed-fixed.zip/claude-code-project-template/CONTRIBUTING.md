# Contributing

Thank you for improving this Claude Code project template.

## Safe contribution model

This is a public repository. Public users should fork the repository and submit pull requests. Do not request direct write access unless you are a trusted maintainer.

## Before opening a pull request

Run:

```bash
./scripts/check-repo-safety.sh
```

Check:

- No secrets or local settings
- No private keys
- No large archive or media files
- No malicious scripts
- No unsafe GitHub Actions changes
- Documentation references `desertfox33/claude-code-project-template`

## Pull request review

Every pull request should explain:

- What changed
- Why it changed
- How it was validated
- Security considerations
- Known risks
