# Claude Code Project Template

A secure, full-featured Claude Code project template owned by **desertfox33**.

Repository target:

```text
https://github.com/desertfox33/claude-code-project-template
```

This project gives you a practical Claude Code workspace with project memory, rules, skills, subagents, custom slash commands, hooks, GitHub security files, and a Dev.to-ready blog post.

## What this template includes

```text
CLAUDE.md                         Project-level operating instructions
CLAUDE.local.md.example           Personal/private local instruction example
.claude/settings.json             Shared Claude Code settings and safe defaults
.mcp.example.json                   Example MCP configuration; keep real .mcp.json local
.claude/settings.local.json.example Local machine override example
.claude/skills/                   Reusable Claude Code skills
.claude/agents/                   Specialized subagents
.claude/commands/                 Project slash commands
.claude/hooks/                    Conservative safety and validation hooks
.claude/rules/                    Path and topic-specific rules
.claude/memory/                   Project memory templates
.claude/workflows/                Repeatable delivery workflows
.github/                          Public repository security and maintenance files
blog/                             Dev.to Markdown article
docs/                             Setup, security, and usage guides
scripts/                          Safe helper scripts
```

## Quick start

After cloning or uploading this repository:

```bash
cd claude-code-project-template
chmod +x scripts/*.sh .claude/hooks/*.sh
./scripts/check-repo-safety.sh
```

Then open the folder in Claude Code:

```bash
claude
```

Claude Code should read `CLAUDE.md`, discover `.claude/skills/`, and apply the shared project instructions.

## Recommended first Claude prompts

```text
Read CLAUDE.md and summarize how this project is organized.
```

```text
Use /project-map and explain which skills, agents, hooks, and rules are available.
```

```text
Use /repo-security-check and review this repository for public release risks.
```

```text
Use /blog-update to improve the Dev.to article for clarity, accuracy, and practical value.
```

## Skills included

| Skill | Use it for |
|---|---|
| `/code-review` | Reviewing code for correctness, maintainability, and risk |
| `/security-review` | Defensive security review and public repository hardening |
| `/testing-patterns` | Writing practical tests and test strategy |
| `/pr-description` | Drafting clear pull request summaries |
| `/documentation-writer` | Writing README, docs, and Dev.to content |
| `/threat-modeling` | Modeling assets, threats, controls, and residual risk |
| `/devsecops-cicd-review` | Reviewing CI/CD and GitHub Actions risk |
| `/cloud-iam-review` | Reviewing cloud IAM and least privilege patterns |
| `/api-security-review` | Reviewing API authentication, authorization, validation, and logging |
| `/incident-response-runbook` | Creating practical incident response steps |
| `/architecture-review` | Reviewing architecture and technical trade-offs |
| `/terraform-iac-review` | Reviewing Terraform/IaC safety and maintainability |
| `/dependency-review` | Reviewing dependency and supply-chain risk |
| `/docker-kubernetes-review` | Reviewing container and Kubernetes configuration |
| `/performance-review` | Reviewing performance risks and bottlenecks |
| `/refactoring-plan` | Planning safe refactoring work |

## Security model

This repository is designed to be public, but public does not mean uncontrolled.

The template includes:

- `.gitignore` rules to block local secrets, `.mcp.json`, and large files.
- `SECURITY.md` for vulnerability reporting.
- `CONTRIBUTING.md` for safe public contribution flow.
- `.github/CODEOWNERS` to route changes to `@desertfox33`.
- Pull request template with security review questions.
- Dependabot configuration for dependency monitoring.
- Conservative hook scripts that block obvious secret/local config edits and risky shell patterns.
- A CI repository-safety check that fails on likely committed secrets, local config, large files, archives, and dangerous script patterns.

You should still enable GitHub repository settings after upload: secret scanning, Dependabot alerts, branch protection/rulesets, and restricted GitHub Actions permissions.

## Upload to GitHub

See:

```text
docs/ipad-github-upload-guide.md
```

## Publish the blog

Use:

```text
blog/devto-claude-code-project-setup.md
```

Copy the Markdown into Dev.to, preview, verify the repository link, and publish when ready.

## Owner

Maintained by **desertfox33**.


## Local MCP configuration safety

Keep real MCP configuration in `.mcp.json` on your workstation only. This file can contain local command paths, environment variables, or credentials depending on the server configuration, so it is ignored by default. Commit only `.mcp.example.json` with safe placeholders.
