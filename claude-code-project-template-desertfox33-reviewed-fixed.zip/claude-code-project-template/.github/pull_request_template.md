## Summary

Describe what changed and why.

## Files Changed

List the major files or folders touched.

## Validation

- [ ] I reviewed the changed files.
- [ ] I ran applicable tests or documented why tests were not run.
- [ ] I checked Markdown/code formatting where relevant.

## Security Review

- [ ] No secrets, tokens, credentials, private keys, or `.env` files were added.
- [ ] No unsafe shell commands or malicious scripts were introduced.
- [ ] GitHub Actions changes use least privilege.
- [ ] Public documentation references `desertfox33/claude-code-project-template`.
- [ ] The change is safe for a public repository.

## Risk and Rollback

Describe known risks and how to revert if needed.
