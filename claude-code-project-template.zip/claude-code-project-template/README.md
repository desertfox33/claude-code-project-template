# Claude Code Project Template

A secure, production-minded Claude Code project template maintained by **desertfox33**.

Repository URL:

```text
https://github.com/desertfox33/claude-code-project-template
```

This repository gives you a reusable project structure for Claude Code with:

- Project memory through `CLAUDE.md`
- Local-only overrides through `CLAUDE.local.md`
- Modular rules under `.claude/rules/`
- Custom slash commands under `.claude/commands/`
- Reusable skills under `.claude/skills/`
- Specialized subagents under `.claude/agents/`
- Safe starter hooks under `.claude/hooks/`
- Persistent project memory under `.claude/memory/`
- Repeatable workflows under `.claude/workflows/`
- Optional MCP configuration through `.mcp.json`
- Public-repo safety files under `.github/`, `SECURITY.md`, and `CONTRIBUTING.md`

## Quick start after publishing to GitHub

```bash
git clone https://github.com/desertfox33/claude-code-project-template.git
cd claude-code-project-template
cp CLAUDE.local.md.example CLAUDE.local.md
cp .claude/settings.local.json.example .claude/settings.local.json
claude
```

Inside Claude Code, try:

```text
/review src/auth
/test src/services
/pr feature/add-auth-validation
```

Or ask naturally:

```text
Use the code-review skill to review this branch for security, reliability, and maintainability.
```

## Upload from iPad

A step-by-step iPad upload guide is included here:

```text
docs/ipad-github-push-guide.md
```

Recommended first-upload approach:

1. Create a public GitHub repository named `claude-code-project-template` under `desertfox33`.
2. Use GitHub Codespaces or a trusted iPad Git client.
3. Push with HTTPS and a fine-grained personal access token.
4. Enable GitHub security features.
5. Protect the `main` branch before accepting public contributions.

## Structure

```text
.
├── CLAUDE.md
├── CLAUDE.local.md.example
├── AGENTS.md
├── .mcp.json
├── .mcp.example.json
├── .github/
│   ├── CODEOWNERS
│   ├── dependabot.yml
│   └── pull_request_template.md
├── .claude/
│   ├── settings.json
│   ├── settings.local.json.example
│   ├── rules/
│   ├── commands/
│   ├── skills/
│   ├── agents/
│   ├── hooks/
│   ├── memory/
│   └── workflows/
├── SECURITY.md
├── CONTRIBUTING.md
└── blog/
    └── devto-claude-code-project-setup.md
```

## Security model for a public repository

A public repository can be safe when write access is controlled and changes are reviewed. This template assumes:

- Only `desertfox33` has direct maintainer access.
- Public users contribute through forks and pull requests.
- No secrets, private keys, tokens, or local Claude overrides are committed.
- Automation is kept minimal and reviewed before use.
- Branch protection or repository rules are enabled in GitHub settings.
- Pull requests are reviewed before merging.

Recommended GitHub settings after the first push:

- Enable two-factor authentication on the `desertfox33` account.
- Enable dependency graph, Dependabot alerts, Dependabot security updates, secret scanning, and push protection where available.
- Protect the `main` branch with a repository ruleset.
- Require pull requests before merging.
- Block force pushes and branch deletion.
- Require conversation resolution before merge.
- Keep GitHub Actions permissions read-only unless a workflow truly needs write access.

## Safety note

Do not install third-party skills, hooks, agents, or MCP servers without review. These files can influence tool use, load extra instructions, or run commands. Keep project-level automation small, auditable, and version-controlled.
