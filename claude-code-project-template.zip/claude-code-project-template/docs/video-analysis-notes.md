# Project Structure Analysis Notes

This repository implements a Claude Code project structure with:

- Root project memory with `CLAUDE.md`
- Local overrides with `CLAUDE.local.md`
- A team roster with `AGENTS.md`
- MCP configuration with `.mcp.json`
- Shared and local Claude settings
- Modular rules
- Custom slash commands
- Skills as directories containing `SKILL.md`
- Specialized agents
- Event-driven hooks
- Persistent memory files
- Multi-step workflows

The implementation is maintained under the `desertfox33` GitHub identity and uses the repository URL:

```text
https://github.com/desertfox33/claude-code-project-template
```

No file in this repository depends on or points to an external template repository.
